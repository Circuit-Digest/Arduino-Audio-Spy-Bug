StreamingData.ino
==================

.. literalinclude:: ../../../../examples/StreamingData/StreamingData.ino
    :lines: 7-
    :linenos:
    :lineno-match:
